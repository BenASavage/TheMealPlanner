// Assignment Meal Planner
// Program CurrentPlans
// Author Fernando Araujo
// Created Nov 19, 2019


package mealplanner;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.GridLayout;
import javax.swing.JScrollBar;
import javax.swing.JButton;

public class CurrentPlans extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CurrentPlans frame = new CurrentPlans();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CurrentPlans() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel lblCurrentPlan = new JLabel("Current Plan");
		lblCurrentPlan.setHorizontalAlignment(SwingConstants.CENTER);
		lblCurrentPlan.setFont(new Font("Javanese Text", Font.BOLD, 24));
		contentPane.add(lblCurrentPlan, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(7, 2, 0, 0));
		
		JPanel btnpanel = new JPanel();
		contentPane.add(btnpanel, BorderLayout.SOUTH);
		
		JButton Viewbtn = new JButton("View Other Plans");
		Viewbtn.setFont(new Font("Javanese Text", Font.PLAIN, 17));
		btnpanel.add(Viewbtn);
		
		JButton Addtobtn = new JButton("Add to this Plan");
		Addtobtn.setFont(new Font("Javanese Text", Font.PLAIN, 17));
		btnpanel.add(Addtobtn);
		
		JButton Resetbtn = new JButton("Reset this Plan");
		Resetbtn.setFont(new Font("Javanese Text", Font.PLAIN, 17));
		btnpanel.add(Resetbtn);
		
		JScrollBar scrollBar = new JScrollBar();
		contentPane.add(scrollBar, BorderLayout.EAST);
	}

}
